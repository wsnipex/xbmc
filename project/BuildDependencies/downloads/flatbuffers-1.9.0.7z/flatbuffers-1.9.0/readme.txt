taken from:
v1.9.0.zip                        https://github.com/google/flatbuffers/archive/